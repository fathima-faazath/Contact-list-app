package com.example.contactslistapplication;

// MainActivity.java

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ContactAdapter contactAdapter;
    private List<Contact> contactList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        contactList = new ArrayList<>();
        contactList.add(new Contact("Raja", "+94 762341789", "raja021@mail.com", "Company Name"));
        contactList.add(new Contact("Mala", "+94 768341789", "mala021@mail.com", "Company Name"));
        contactList.add(new Contact("Kamala", "+94 765661789", "kamala021@mail.com", "Company Name"));
        contactList.add(new Contact("Vimala", "+94 760441789", "vimala021@mail.com", "Company Name"));
        contactList.add(new Contact("Ajai", "+94 762341744", "ajai021@mail.com", "Company Name"));
        contactList.add(new Contact("Jin", "+94 762555789", "jin021@mail.com", "Company Name"));
        contactList.add(new Contact("Kumar", "+94 762341832", "kumar021@mail.com", "Company Name"));
        contactList.add(new Contact("Kamal", "+94 762341000", "kamal021@mail.com", "Company Name"));
        contactList.add(new Contact("Anjali", "+94 762341789", "anjali021@mail.com", "Company Name"));
        contactList.add(new Contact("Nila", "+94 762098789", "nila021@mail.com", "Company Name"));
        contactList.add(new Contact("Sunil", "+94 762348769", "sunil021@mail.com", "Company Name"));
        contactList.add(new Contact("Vimal", "+94 768881789", "vimal021@mail.com", "Company Name"));
        contactList.add(new Contact("Babar", "+94 762541789", "babarmail021@mail.com", "Company Name"));
        contactList.add(new Contact("Bipan", "+94 762366789", "bipan021@mail.com", "Company Name"));
        contactList.add(new Contact("Barek", "+94 76233389", "barek021@mail.com", "Company Name"));
        contactList.add(new Contact("Bappa", "+94 762341056", "bappa021@mail.com", "Company Name"));
        contactList.add(new Contact("Chamel", "+94 762675389", "chamel021@mail.com", "Company Name"));
        contactList.add(new Contact("Chapal", "+94 762302789", "chapal021@mail.com", "Company Name"));


        ContactAdapter adapter = new ContactAdapter(this, contactList);
        recyclerView.setAdapter(adapter);
    }
}
