package com.example.contactslistapplication;

/// Contact.java

public class Contact {
    private String name;
    private String phoneNumber;
    private String email;
    private String company;

    public Contact(String name, String phoneNumber, String email, String company) {
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.email = email;
        this.company = company;
    }

    public String getName() {
        return name;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getEmail() {
        return email;
    }

    public String getCompany() {
        return company;
    }
}
