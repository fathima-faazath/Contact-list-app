package com.example.contactslistapplication;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ContactDetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_detail);

        TextView nameTextView = findViewById(R.id.contact_detail_name);
        TextView phoneTextView = findViewById(R.id.contact_phone_detail);
        TextView emailTextView = findViewById(R.id.contact_email_detail);
        TextView companyTextView = findViewById(R.id.contact_company_detail);

        // Get the data from the intent
        String name = getIntent().getStringExtra("name");
        String phone = getIntent().getStringExtra("phone");
        String email = getIntent().getStringExtra("email");
        String company = getIntent().getStringExtra("company");

        // Set the data to the views
        nameTextView.setText(name);
        phoneTextView.setText(phone);
        emailTextView.setText(email);
        companyTextView.setText(company);
    }
}
